
document.body.style.backgroundColor  = "lightyellow";

document.getElementById("heading").innerHTML = "JavaScript";

document.getElementById('heading').style.fontSize='35px';

document.getElementById("p1").innerHTML = "JavaScript is apowerful, flexible, and fast programming language.";

document.getElementById("p2").innerHTML = "JavaScript powers thedynamic behavior on websites.";

document.getElementById("p3").innerHTML = "JavaScript remains atthe core of web development.";

document.getElementById('p1').style.color='red';

document.getElementById('p2').style.color='blue';

document.getElementById('p3').style.color='green';